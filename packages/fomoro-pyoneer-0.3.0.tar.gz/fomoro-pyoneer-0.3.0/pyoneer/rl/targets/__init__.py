from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from pyoneer.rl.targets.target_ops import DiscountedReturns, GeneralizedAdvantages

__all__ = ["DiscountedReturns", "GeneralizedAdvantages"]
