from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from pyoneer.activations.activations_impl import swish

__all__ = ["swish"]
